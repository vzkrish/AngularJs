export interface Southcusine {
    id: number;
    name: string;
    ratePerUnit: number;
    image: string;
}
