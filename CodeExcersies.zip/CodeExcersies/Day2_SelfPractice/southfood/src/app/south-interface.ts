export interface SouthInterface {
    id: number ;
    name: string ;
    ratePerUnit: number;
    image: string;
}
