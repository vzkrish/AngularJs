import {SalesMan} from './salesman';

const ramesh = new SalesMan(100,'Krish','1472583695');
console.log(ramesh.toString());