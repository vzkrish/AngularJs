"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var salesman_1 = require("./salesman");
var ramesh = new salesman_1.SalesMan(100, 'Krish', '1472583695');
console.log(ramesh.toString());
