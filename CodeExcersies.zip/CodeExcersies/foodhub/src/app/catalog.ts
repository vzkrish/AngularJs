export interface Catalog {
    id: number ;
    name: string ;
    ratePerUnit: number;
    img: string;
}
