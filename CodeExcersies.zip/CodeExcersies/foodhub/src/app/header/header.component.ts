import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  mainTitle = 'Welcome to Food Hub';

  pageHeadLinks = ['Restuarant','Order','TrackOrder'];
  constructor() { }

  ngOnInit() {
  }

}
